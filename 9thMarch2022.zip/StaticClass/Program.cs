﻿using System;

namespace StaticClass
{
    // By Default all the methods and fields must be static inside the static class.
    static class StaticCLS
    {
        public static int a;
        public static void Demo()
        {
            Console.WriteLine("Static method of static class called.");
        }
    }
    class NormalCLS
    {
        public static int b;
        public static void Demo2()
        {
            Console.WriteLine("Static method of normal class called.");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            StaticCLS.a = 1000;
            StaticCLS.Demo();

            NormalCLS.b = 2000;
            NormalCLS.Demo2();

            Console.ReadKey();

        }
    }
}
