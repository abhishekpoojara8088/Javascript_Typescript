﻿using System;
using SubNameSpace;

namespace MainNameSpace
{
    public class DemoCLS1
    {
        public int a;
    }
    class Program
    {
        static void Main(string[] args)
        {
            DemoCLS1 DCLS1 = new DemoCLS1();
            DCLS1.a = 10;

            SubNameSpace.DemoCLS1 DCLS2 = new SubNameSpace.DemoCLS1();
            DCLS2.a = 20;

            Console.ReadKey();
        }
    }
}
