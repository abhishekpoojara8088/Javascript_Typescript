﻿using System;

namespace InheritanceWithDataHiding
{ 
    class DataHidingInternalDemoCLS
    {
        internal int intern;
    }
}

namespace Inheritance
{
    class Parent
    {
        //By Default All Variables Are Private Variables.
        
        private int a;
        protected int b;
        public int c;
        internal int i;
        public void DemoInheritancePrivate()
        {
            a = 100;
        }
    }
    class Child:Parent
    {
        public void DemoInheritanceProtected()
        {
            b = 100;
        }

    }
    public class Program
    {
        static void Main(string[] args)
        {
            Child C = new Child();
            C.c = 1000;
            C.i = 3000;

            Parent P = new Parent();
            P.c = 2000;
            P.i = 2000;

            InheritanceWithDataHiding.DataHidingInternalDemoCLS DemoCLS = new InheritanceWithDataHiding.DataHidingInternalDemoCLS();
            DemoCLS.intern = 1000;
        }
    }
}
