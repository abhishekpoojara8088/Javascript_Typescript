﻿using System;

namespace Polymorphism
{
    
    class OverloadingDemoCLS
    {
        public void Demo()
        {
            Console.WriteLine("No Return Type, No Parameters.");
        }
        public void Demo(int a)
        {
            Console.WriteLine("No Return Type, One Int Parameter.");
        }
        public void Demo(string a)
        {
            Console.WriteLine("No Return Type, One String Parameter.");
        }
        public void Demo(string a,int b)
        {
            Console.WriteLine("No Return Type, One String Parameter & One Int Parameter.");
        }

    }
    class Program
    {


        static void Main(string[] args)
        {
            OverloadingDemoCLS Obj = new OverloadingDemoCLS();
            Obj.Demo();
            Obj.Demo("ABC",10);
            Console.ReadKey();
        }
    }
}
