﻿using System;

namespace PartialCLS
{
    partial class PartialCLSDemo
    {
        public int a;
    }
    partial class PartialCLSDemo
    {
        public int b;
    }
    partial class PartialCLSDemo
    {
        public int c;
    }
    class Program
    {
        static void Main(string[] args)
        {
            PartialCLSDemo PObj = new PartialCLSDemo();
            PObj.a = 1000;
            PObj.b = 2000;
            PObj.c = 3000;
            Console.ReadKey();
        }
    }
}
