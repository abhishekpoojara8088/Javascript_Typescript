﻿using System;

namespace SubNameSpace
{
    public class DemoCLS1
    {
        public int a;
    }
}
