﻿using System;

namespace ClassAndStructure
{
    struct Struct_Encapsulation
    {
        public int a;
    }

    class CLS_Encapsulation
    {
        public int a;
        public CLS_Encapsulation() { 
        }
    }
    class Program
    {
        
        static void Main(string[] args)
        {
            //Structure
            Struct_Encapsulation CStruct1 = new Struct_Encapsulation();
            Struct_Encapsulation CStruct2 = new Struct_Encapsulation();
            Struct_Encapsulation CStruct3 = CStruct2;
            Struct_Encapsulation CStruct4 = CStruct1;
            Struct_Encapsulation CStruct5 = new Struct_Encapsulation();
            
            CStruct1.a = 10;
            CStruct2.a = 20;
            CStruct3.a = 30;
            CStruct4.a = 40;
            CStruct5.a = 50;

            Console.WriteLine("CStruct1.a:" + CStruct1.a);
            Console.WriteLine("CStruct2.a:" + CStruct2.a);
            Console.WriteLine("CStruct3.a:" + CStruct3.a);
            Console.WriteLine("CStruct4.a:" + CStruct4.a);
            Console.WriteLine("CStruct5.a:" + CStruct5.a);

            // Class
            CLS_Encapsulation CObj1 = new CLS_Encapsulation();
            CLS_Encapsulation CObj2 = new CLS_Encapsulation();
            CLS_Encapsulation CObj3 = CObj2;
            CLS_Encapsulation CObj4 = CObj1;
            CLS_Encapsulation CObj5 = new CLS_Encapsulation();
            CLS_Encapsulation CObj6 = CObj5;


            CObj1.a = 10;
            CObj2.a = 20;
            CObj3.a = 30;
            CObj4.a = 40;
            CObj5.a = 50;

            Console.WriteLine("CObj1.a:" + CObj1.a);
            Console.WriteLine("CObj2.a:" + CObj2.a);
            Console.WriteLine("CObj3.a:" + CObj3.a);
            Console.WriteLine("CObj4.a:" + CObj4.a);
            Console.WriteLine("CObj5.a:" + CObj5.a);


            Console.ReadKey();
        }
    }
}
